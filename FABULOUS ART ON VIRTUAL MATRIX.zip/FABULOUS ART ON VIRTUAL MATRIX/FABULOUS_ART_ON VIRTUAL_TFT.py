import tkinter as tk
from tkinter import Canvas
import colorsys
import random
import time

# TFT parameters
TFT_WIDTH = 320
TFT_HEIGHT = 240

# Define colors
ILI9341_BLACK = "black"
ILI9341_GREEN = "#00FF00"  # Green color code
MAGENTA = "#FF00FF"
YELLOW = "#FFFF00"

class VirtualTFT:
    def __init__(self, master):
        self.master = master
        self.canvas = Canvas(master, width=TFT_WIDTH, height=TFT_HEIGHT, bg=ILI9341_BLACK)
        self.canvas.pack()

        # Digital clock setup
        self.clock_text = self.canvas.create_text(
            TFT_WIDTH // 2,
            TFT_HEIGHT - 20,
            text="",
            font=("Arial", 16),
            fill=ILI9341_GREEN
        )

        # Main loop
        self.draw_circles()
        self.draw_squares()
        self.draw_triangles()
        self.draw_rainbow_background()

        # Print message in magenta color
        self.canvas.create_text(
            TFT_WIDTH // 2,
            TFT_HEIGHT // 2,
            text="Code by Arvind 4/12/23",
            font=("Arial", 20),
            fill=MAGENTA
        )
        self.master.update()

    def update_clock(self):
        current_time = time.strftime("%H:%M:%S")
        self.canvas.itemconfig(self.clock_text, text=current_time)
        self.master.after(1000, self.update_clock)

    def draw_circles(self):
        for _ in range(35):
            random_color = "#{:02x}{:02x}{:02x}".format(
                random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
            )

            x, y = random.randint(50, TFT_WIDTH - 50), random.randint(50, TFT_HEIGHT - 50)
            radius = random.randint(10, 50)
            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, outline=random_color)
            self.master.update()
            self.master.after(100)  # Adjust the delay to control the drawing speed

    def draw_squares(self):
        for side_length in range(200, 0, -20):
            # Set the TFT color to yellow
            color = YELLOW

            # Draw the square
            x = TFT_WIDTH / 2 - side_length / 2
            y = TFT_HEIGHT / 2 - side_length / 2
            self.canvas.create_rectangle(x, y, x + side_length, y + side_length, fill=color)
            self.master.update()
            self.master.after(500)  # Adjust delay if needed

            # Clear the square by filling it with the background color
            self.canvas.create_rectangle(x, y, x + side_length, y + side_length, fill=ILI9341_BLACK)
            self.master.update()

    def draw_triangles(self):
        for _ in range(35):
            random_color = "#{:02x}{:02x}{:02x}".format(
                random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
            )

            x1, y1 = random.randint(50, TFT_WIDTH - 50), random.randint(50, TFT_HEIGHT - 50)
            x2, y2 = x1 + random.randint(-30, 30), y1 + random.randint(-30, 30)
            x3, y3 = x1 + random.randint(-30, 30), y1 + random.randint(-30, 30)

            self.canvas.create_polygon(x1, y1, x2, y2, x3, y3, outline=random_color)
            self.master.update()
            self.master.after(100)  # Adjust the delay to control the drawing speed

    def draw_rainbow_background(self):
        for i in range(TFT_WIDTH):
            hue = int((i / TFT_WIDTH) * 255)
            color = "#{:02x}{:02x}{:02x}".format(
                *tuple(int(c * 255) for c in colorsys.hsv_to_rgb(hue / 255, 1, 1))
            )
            self.canvas.create_line(i, 0, i, TFT_HEIGHT, fill=color)
            self.master.update()
        self.master.after(500)  # Adjust delay if needed


root = tk.Tk()
root.title("Virtual TFT Display")
virtual_tft = VirtualTFT(root)
virtual_tft.update_clock()  # Start the clock update
root.mainloop()

