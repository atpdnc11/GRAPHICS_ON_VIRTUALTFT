import tkinter as tk
from tkinter import Canvas
import colorsys
import random
import math

# TFT parameters
TFT_WIDTH = 320
TFT_HEIGHT = 240

# Define colors
ILI9341_BLACK = black
CYAN = #00FFFF  # Cyan color code

class VirtualTFT
    def __init__(self, master)
        self.master = master
        self.canvas = Canvas(master, width=TFT_WIDTH, height=TFT_HEIGHT, bg=ILI9341_BLACK)
        self.canvas.pack()

        # Main loop
        self.draw_shapes()

        # Print message in cyan color
        self.canvas.create_text(
            TFT_WIDTH  2,
            TFT_HEIGHT  2,
            text=Code by Arvind 41223,
            font=(Arial, 20),
            fill=CYAN
        )
        self.master.update()

    def draw_shapes(self)
        for _ in range(10)
            shape_type = random.choice([circle, triangle])
            position = (random.randint(0, TFT_WIDTH), random.randint(0, TFT_HEIGHT))

            if shape_type == circle
                self.draw_turtle_circle(position)
            elif shape_type == triangle
                self.draw_turtle_triangle(position)

            self.master.update()
            self.master.after(100)  # Adjust the delay to control the drawing speed

    def draw_turtle_circle(self, position)
        radius = random.randint(10, 50)
        color = self.get_random_rainbow_color()

        x, y = position
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)

    def draw_turtle_triangle(self, position)
        side_length = random.randint(10, 50)
        color = self.get_random_rainbow_color()

        x, y = position
        x1, y1 = x, y - side_length  math.sqrt(3)
        x2, y2 = x - side_length  2, y + side_length  (2  math.sqrt(3))
        x3, y3 = x + side_length  2, y + side_length  (2  math.sqrt(3))

        self.canvas.create_polygon(x1, y1, x2, y2, x3, y3, fill=color)

    def get_random_rainbow_color(self)
        hue = random.uniform(0, 1)
        return #{02x}{02x}{02x}.format(
            tuple(int(c  255) for c in colorsys.hsv_to_rgb(hue, 1, 1))
        )

# Usage
root = tk.Tk()
root.title(Virtual TFT Display)
virtual_tft = VirtualTFT(root)
root.mainloop()

