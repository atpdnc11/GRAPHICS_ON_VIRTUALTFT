import tkinter as tk
import time
import colorsys

class LEDMatrixSimulator:
    def __init__(self, root, num_rows, num_cols, led_size):
        self.root = root
        self.num_rows = num_rows
        self.num_cols = num_cols
        self.led_size = led_size

        self.canvas = tk.Canvas(root, width=num_cols * led_size, height=num_rows * led_size, bg="black")
        self.canvas.pack()

        self.leds = [[None] * num_cols for _ in range(num_rows)]
        self.init_led_matrix()

    def init_led_matrix(self):
        for row in range(self.num_rows):
            for col in range(self.num_cols):
                x = col * self.led_size
                y = row * self.led_size
                led = self.canvas.create_rectangle(x, y, x + self.led_size, y + self.led_size, outline="black", fill="black")
                self.leds[row][col] = led

    def display_text_on_matrix(self, text):
        colors = ["red", "green", "blue", "green"]
        for col in range(len(text)):
            for i in range(self.num_rows):
                for j in range(self.num_cols):
                    self.canvas.itemconfig(self.leds[i][j], fill="black")

            color = colors[col % len(colors)]
            x = col * self.led_size + self.led_size // 2
            y = self.led_size // 2
            self.canvas.create_text(x, y, text=text[col], fill=color, font=("Helvetica", 12, "bold"))
            self.root.update()
            time.sleep(0.5)

if __name__ == "__main__":
    root = tk.Tk()
    root.title("LED Matrix Simulator")

    num_rows = 8
    num_cols = 8
    led_size = 60

    simulator = LEDMatrixSimulator(root, num_rows, num_cols, led_size)
    simulator.display_text_on_matrix("ARVIND ")

    root.mainloop()

